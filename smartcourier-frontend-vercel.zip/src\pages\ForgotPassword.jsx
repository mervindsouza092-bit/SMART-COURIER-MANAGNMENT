import { useState } from 'react'
import { Link } from 'react-router-dom'
import AuthShell from '../components/auth/AuthShell'
import Input from '../components/common/Input'
import Loading from '../components/common/Loading'
import AuthModal from '../components/auth/AuthModal'
export default function ForgotPassword() {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)
  const submit = (event) => { event.preventDefault(); if (!email) return; setLoading(true); setTimeout(() => { setLoading(false); setSent(true) }, 600) }
  return <AuthShell eyebrow="RECOVERY PROTOCOL" title={<>RESET<br /><span>ACCESS.</span></>}><h2>RESET ACCESS</h2><p className="auth-subtitle">Enter your registered email to receive password reset instructions.</p><form onSubmit={submit}><Input label="EMAIL ADDRESS" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@company.com" /><button className="button auth-submit" disabled={loading}>{loading ? <Loading label="PROCESSING REQUEST..." /> : 'SEND RESET LINK ↗'}</button></form><p className="auth-switch"><Link to="/login">← BACK TO LOGIN</Link></p>{sent && <AuthModal title="RESET LINK SENT" text="Check your email for password reset instructions. Demo mode: password reset simulation successful." action={<Link className="button" to="/reset-password">CONTINUE TO RESET ↗</Link>} />}</AuthShell>
}
