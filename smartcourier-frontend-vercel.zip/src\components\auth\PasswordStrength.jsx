export default function PasswordStrength({ password }) {
  const score = [password.length >= 8, /[A-Z]/.test(password), /\d/.test(password), /[^A-Za-z0-9]/.test(password)].filter(Boolean).length
  const label = score < 2 ? 'WEAK' : score < 4 ? 'MEDIUM' : 'STRONG'
  return <div className="password-strength"><div>{[1, 2, 3, 4].map((item) => <i key={item} className={item <= score ? `strength-${label.toLowerCase()}` : ''} />)}</div><span>{password ? label : 'PASSWORD STRENGTH'}</span></div>
}
