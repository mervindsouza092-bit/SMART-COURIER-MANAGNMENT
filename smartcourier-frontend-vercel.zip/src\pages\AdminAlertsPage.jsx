import { AlertTriangle, ArrowRight, CheckCheck, Clock3, ShieldAlert } from 'lucide-react'

const alerts = [
  { id: 'AL-201', type: 'DELAY', priority: 'HIGH', shipments: 'SC-2026-94821', message: 'Delivery exceeded expected route time by 18 minutes.', state: 'Open' },
  { id: 'AL-202', type: 'PAYMENT', priority: 'MEDIUM', shipments: 'SC-2026-45166', message: 'An attempted payment has failed during verification.', state: 'Open' },
  { id: 'AL-203', type: 'COURIER', priority: 'HIGH', shipments: 'SC-2026-08111', message: 'Courier has been inactive for 42 minutes during an active assignment.', state: 'Monitoring' },
  { id: 'AL-204', type: 'ANOMALY', priority: 'LOW', shipments: 'SC-2026-10990', message: 'Unusual location deviation detected and flagged for review.', state: 'Resolved' },
]

export default function AdminAlertsPage() {
  return (
    <div className="page-shell analytics-shell">
      <div className="section-heading" style={{ marginBottom: 20 }}>
        <div className="eyebrow"><i /> ADMIN ALERT CENTER</div>
        <h2>Operations alerts</h2>
      </div>

      <div className="alerts-list">
        {alerts.map((alert) => (
          <article key={alert.id} className="alert-card">
            <div className="alert-header">
              <div className="alert-meta">
                <span className="inline-badge">{alert.type}</span>
                <span className={`priority-pill ${String(alert.priority).toLowerCase()}`}>{alert.priority}</span>
              </div>
              <span className="alert-state">{alert.state}</span>
            </div>
            <h3>{alert.shipments}</h3>
            <p>{alert.message}</p>
            <div className="alert-actions">
              <button className="button button-small">View</button>
              <button className="button button-small button-ghost">Resolve</button>
            </div>
          </article>
        ))}
      </div>
    </div>
  )
}
