import { Link, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import AuthShell from '../components/auth/AuthShell'
import Input from '../components/common/Input'
import Loading from '../components/common/Loading'
import Toast from '../components/common/Toast'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const [form, setForm] = useState({ email: '', password: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [toast, setToast] = useState(null)
  const { login, demoAccounts } = useAuth()
  const navigate = useNavigate()
  const update = (key) => (event) => { setForm({ ...form, [key]: event.target.value }); setError('') }
  const submit = async (event) => { event.preventDefault(); if (!form.email || !form.password) return setError('Please enter your email and password.'); setLoading(true); const result = await login(form.email, form.password); setLoading(false); if (!result.ok) return setToast({ type: 'error', message: 'INVALID CREDENTIALS — ' + result.message }); navigate('/select-role') }
  return <AuthShell eyebrow="SECURE ACCESS" title={<>SMART LOGISTICS.<br /><span>SMARTER FUTURE.</span></>}><h2>WELCOME BACK</h2><p className="auth-subtitle">Sign in to continue to Smart Courier.</p><form onSubmit={submit}><Input label="EMAIL ADDRESS" name="email" value={form.email} onChange={update('email')} error={error && !form.email ? 'EMAIL REQUIRED' : ''} placeholder="you@company.com" /><Input label="PASSWORD" name="password" type="password" value={form.password} onChange={update('password')} error={error && !form.password ? 'PASSWORD REQUIRED' : ''} placeholder="••••••••" /><div className="form-options"><label><input type="checkbox" /> Remember me</label><Link to="/forgot-password">Forgot password?</Link></div><button className="button auth-submit" disabled={loading}>{loading ? <Loading label="AUTHENTICATING..." /> : 'LOGIN TO SYSTEM ↗'}</button></form><div className="auth-divider"><span>OR</span></div><div className="demo-access"><span>DEMO ACCESS</span>{Object.entries(demoAccounts).map(([role, account]) => <button type="button" onClick={() => setForm({ email: account.email, password: account.password })} key={role}>USE {role.toUpperCase()} DEMO</button>)}</div><p className="auth-switch">Don't have an account? <Link to="/register">CREATE ACCOUNT</Link></p><Toast toast={toast} onClose={() => setToast(null)} /></AuthShell>
}
