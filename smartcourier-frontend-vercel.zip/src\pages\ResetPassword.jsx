import { useState } from 'react'
import { Link } from 'react-router-dom'
import AuthShell from '../components/auth/AuthShell'
import Input from '../components/common/Input'
import PasswordStrength from '../components/auth/PasswordStrength'
import AuthModal from '../components/auth/AuthModal'
export default function ResetPassword() {
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [done, setDone] = useState(false)
  const submit = (event) => { event.preventDefault(); if (password.length >= 8 && password === confirm) setDone(true) }
  return <AuthShell eyebrow="RECOVERY PROTOCOL" title={<>NEW<br /><span>CREDENTIALS.</span></>}><h2>UPDATE PASSWORD</h2><p className="auth-subtitle">Create a new secure password for your account.</p><form onSubmit={submit}><Input label="NEW PASSWORD" type="password" value={password} onChange={(event) => setPassword(event.target.value)} /><PasswordStrength password={password} /><Input label="CONFIRM PASSWORD" type="password" value={confirm} onChange={(event) => setConfirm(event.target.value)} /><button className="button auth-submit">UPDATE PASSWORD ↗</button></form><p className="auth-switch"><Link to="/login">← BACK TO LOGIN</Link></p>{done && <AuthModal title="PASSWORD UPDATED" text="Your credentials have been updated successfully." action={<Link className="button" to="/login">RETURN TO LOGIN ↗</Link>} />}</AuthShell>
}
