import { useEffect, useMemo, useState } from 'react'
import {
  Bell, BellRing, Box, Building2, CheckCircle2, ChevronRight, CircleDashed,
  Clock3, CreditCard, Globe, LayoutGrid, LogOut, Mail, MapPinned, Menu,
  PackageCheck, PaintbrushVertical, Phone, PlusCircle, Search, Settings,
  ShieldCheck, SlidersHorizontal, Sparkles, Truck, User, UserRound, Wallet
} from 'lucide-react'
import { NavLink, Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { shipmentApi, api } from '../services/api'
import { mockShipments, notifications as initialNotifications, userProfile, userSettings } from '../data/mockData'

const navItems = [
  { label: 'Overview', to: '/dashboard/overview', icon: LayoutGrid, exact: true },
  { label: 'Book Shipment', to: '/dashboard/booking', icon: PlusCircle },
  { label: 'Shipments', to: '/dashboard/shipments', icon: PackageCheck },
  { label: 'Tracking', to: '/dashboard/tracking', icon: MapPinned },
  { label: 'Notifications', to: '/dashboard/notifications', icon: BellRing },
  { label: 'Profile', to: '/dashboard/profile', icon: UserRound },
  { label: 'Settings', to: '/dashboard/settings', icon: Settings },
]

const STATUS_CLASS_MAP = {
  'Booked': 'status-booked',
  'In Transit': 'status-in-transit',
  'Out for Delivery': 'status-out-for-delivery',
  'Delivered': 'status-delivered',
  'Delayed': 'status-delayed',
  'Cancelled': 'status-cancelled',
}

function classNames(...values) {
  return values.filter(Boolean).join(' ')
}

function StatusBadge({ status }) {
  const value = STATUS_CLASS_MAP[status] || 'status-booked'
  return <span className={classNames('status-badge', value)}>{status}</span>
}

function OverviewPage({ shipments }) {
  const activeCount = shipments.filter((shipment) => shipment.status !== 'Delivered').length
  const deliveredCount = shipments.filter((shipment) => shipment.status === 'Delivered').length
  const totalValue = shipments.reduce((sum, shipment) => sum + Number(String(shipment.value).replace(/[^\d.]/g, '')), 0)
  const quickActions = [
    { label: 'Book a parcel', icon: PlusCircle, hint: 'Dispatch a new consignment' },
    { label: 'Track shipment', icon: MapPinned, hint: 'Follow live updates' },
    { label: 'Create return', icon: Truck, hint: 'Reverse logistics' },
    { label: 'View invoices', icon: Wallet, hint: 'Billing & payout' },
  ]

  return (
    <>
      <div className="stats-grid">
        <article className="kpi-card">
          <div className="kpi-icon purple"><PackageCheck size={18} /></div>
          <strong>{shipments.length}</strong>
          <span>Total shipments</span>
        </article>
        <article className="kpi-card">
          <div className="kpi-icon cyan"><Truck size={18} /></div>
          <strong>{activeCount}</strong>
          <span>In motion</span>
        </article>
        <article className="kpi-card">
          <div className="kpi-icon green"><CheckCircle2 size={18} /></div>
          <strong>{deliveredCount}</strong>
          <span>Delivered</span>
        </article>
        <article className="kpi-card">
          <div className="kpi-icon orange"><CreditCard size={18} /></div>
          <strong>₹{Math.round(totalValue).toLocaleString('en-IN')}</strong>
          <span>Spend this cycle</span>
        </article>
      </div>

      <div className="card-block">
        <div className="card-heading">
          <h2>Quick actions</h2>
        </div>
        <div className="quick-actions-grid">
          {quickActions.map(({ label, icon: Icon, hint }) => (
            <div key={label} className="quick-action-card">
              <div className="quick-action-icon"><Icon size={17} /></div>
              <span>{label}</span>
              <small>{hint}</small>
            </div>
          ))}
        </div>
      </div>

      <div className="card-block">
        <div className="card-heading">
          <h2>Recent shipments</h2>
          <NavLink className="text-link" to="/dashboard/shipments">View all</NavLink>
        </div>
        <div className="table-wrap">
          <table className="user-table">
            <thead>
              <tr>
                <th>Shipment</th>
                <th>Route</th>
                <th>Status</th>
                <th>ETA</th>
                <th>Value</th>
              </tr>
            </thead>
            <tbody>
              {shipments.slice(0, 4).map((shipment) => (
                <tr key={shipment.id}>
                  <td><strong>{shipment.id}</strong></td>
                  <td>{shipment.origin} → {shipment.destination}</td>
                  <td><StatusBadge status={shipment.status} /></td>
                  <td>{shipment.eta}</td>
                  <td>{shipment.value}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  )
}

function BookingPage({ shipments, setShipments, selectedShipmentId, setSelectedShipmentId, navigate }) {
  const [currentStep, setCurrentStep] = useState(0)
  const [form, setForm] = useState({
    service: 'Express',
    parcelType: 'Electronics',
    weight: '4.8',
    distance: '220',
    origin: 'New York, NY',
    destination: 'Boston, MA',
    pickupDate: '2026-09-20',
    recipient: 'Katherine Collins',
    contact: '+1 (415) 771-1102',
    instructions: 'Leave at the front desk if not home.'
  })

  const steps = ['Shipment details', 'Delivery details', 'Review & confirm']
  const chargeRate = form.service === 'Express' ? 1.25 : form.service === 'Same Day' ? 1.6 : 1.08
  const subtotal = 50 + Number(form.weight || 0) * 20 + Number(form.distance || 0) * 2
  const estimate = (subtotal * chargeRate).toFixed(2)

  const updateField = (field, value) => setForm((current) => ({ ...current, [field]: value }))

  const canAdvance = () => {
    if (currentStep === 0) return form.origin && form.destination && form.weight
    if (currentStep === 1) return form.recipient && form.contact
    return true
  }

  const handleSubmit = () => {
    const nextShipment = {
      id: `SC-${Math.floor(10000 + Math.random() * 90000)}`,
      status: 'Booked',
      statusClass: 'status-booked',
      service: form.service,
      origin: form.origin,
      destination: form.destination,
      eta: 'Tomorrow, 9:00 AM',
      progress: 14,
      value: `₹${estimate}`,
      weight: `${form.weight} kg`,
      courier: 'Pending assignment',
      contact: form.contact,
      lastUpdate: 'Request submitted and awaiting courier assignment.',
      timeline: [
        { label: 'Booked', time: 'Today', complete: true },
        { label: 'Pickup', time: 'Pending', complete: false },
        { label: 'In Transit', time: 'Pending', complete: false },
        { label: 'Hub Scan', time: 'Pending', complete: false },
        { label: 'Delivery', time: 'Pending', complete: false },
      ]
    }

    setShipments((current) => [nextShipment, ...current])
    setSelectedShipmentId(nextShipment.id)
    navigate('/dashboard/shipments')
  }

  const renderStep = () => {
    if (currentStep === 0) {
      return (
        <div className="booking-grid">
          <label className="field">
            <span>Service</span>
            <select value={form.service} onChange={(event) => updateField('service', event.target.value)}>
              <option>Express</option>
              <option>Priority</option>
              <option>Standard</option>
              <option>Same Day</option>
            </select>
          </label>
          <label className="field">
            <span>Parcel type</span>
            <select value={form.parcelType} onChange={(event) => updateField('parcelType', event.target.value)}>
              <option>Electronics</option>
              <option>Fashion</option>
              <option>Documents</option>
              <option>Home goods</option>
            </select>
          </label>
          <label className="field">
            <span>Origin</span>
            <input value={form.origin} onChange={(event) => updateField('origin', event.target.value)} placeholder="From city" />
          </label>
          <label className="field">
            <span>Destination</span>
            <input value={form.destination} onChange={(event) => updateField('destination', event.target.value)} placeholder="To city" />
          </label>
          <label className="field">
            <span>Weight (kg)</span>
            <input type="number" value={form.weight} onChange={(event) => updateField('weight', event.target.value)} />
          </label>
          <label className="field">
            <span>Distance (km)</span>
            <input type="number" value={form.distance} onChange={(event) => updateField('distance', event.target.value)} />
          </label>
          <label className="field field-span-2">
            <span>Pickup date</span>
            <input type="date" value={form.pickupDate} onChange={(event) => updateField('pickupDate', event.target.value)} />
          </label>
        </div>
      )
    }

    if (currentStep === 1) {
      return (
        <div className="booking-grid">
          <label className="field">
            <span>Recipient</span>
            <input value={form.recipient} onChange={(event) => updateField('recipient', event.target.value)} />
          </label>
          <label className="field">
            <span>Contact number</span>
            <input value={form.contact} onChange={(event) => updateField('contact', event.target.value)} />
          </label>
          <label className="field field-span-2">
            <span>Special instructions</span>
            <textarea value={form.instructions} onChange={(event) => updateField('instructions', event.target.value)} rows="5" />
          </label>
        </div>
      )
    }

    return (
      <div className="review-panel">
        <div className="review-item">
          <span>Route</span>
          <strong>{form.origin} → {form.destination}</strong>
        </div>
        <div className="review-item">
          <span>Service</span>
          <strong>{form.service}</strong>
        </div>
        <div className="review-item">
          <span>Recipient</span>
          <strong>{form.recipient}</strong>
        </div>
        <div className="review-item">
          <span>Pickup</span>
          <strong>{new Date(form.pickupDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</strong>
        </div>
        <div className="cost-preview">
          <small>Estimated cost</small>
          <strong>₹{Number(estimate).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
          <small>Includes handling, fuel, and service surcharge.</small>
        </div>
      </div>
    )
  }

  return (
    <div className="card-block">
      <div className="card-heading">
        <h2>Book a shipment</h2>
      </div>
      <div className="stepper">
        {steps.map((label, index) => (
          <button
            key={label}
            type="button"
            className={classNames('step-pill', index === currentStep && 'step-pill-active', index < currentStep && 'step-pill-complete')}
            onClick={() => index < currentStep && setCurrentStep(index)}
          >
            <span>{index + 1}</span>
            {label}
          </button>
        ))}
      </div>
      <div className="booking-panel">{renderStep()}</div>
      <div className="form-actions right-align">
        {currentStep > 0 && (
          <button type="button" className="button button-ghost" onClick={() => setCurrentStep((value) => value - 1)}>Back</button>
        )}
        {currentStep < steps.length - 1 ? (
          <button type="button" className="button" onClick={() => canAdvance() && setCurrentStep((value) => value + 1)} disabled={!canAdvance()}>Continue</button>
        ) : (
          <button type="button" className="button" onClick={handleSubmit}>Confirm booking</button>
        )}
      </div>
    </div>
  )
}

function ShipmentsPage({ shipments, selectedShipmentId, setSelectedShipmentId, searchTerm, setSearchTerm, statusFilter, setStatusFilter, serviceFilter, setServiceFilter }) {
  const filteredShipments = useMemo(() => shipments.filter((shipment) => {
    const matchesSearch = [shipment.id, shipment.origin, shipment.destination, shipment.status].join(' ').toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || shipment.status === statusFilter
    const matchesService = serviceFilter === 'all' || shipment.service === serviceFilter
    return matchesSearch && matchesStatus && matchesService
  }), [shipments, searchTerm, statusFilter, serviceFilter])

  const selectedShipment = shipments.find((shipment) => shipment.id === selectedShipmentId) || filteredShipments[0] || shipments[0]

  return (
    <div className="content-split">
      <div className="card-block wide">
        <div className="card-heading">
          <h2>Shipments</h2>
        </div>

        <div className="toolbar-row">
          <label className="search-box">
            <Search size={15} />
            <input value={searchTerm} onChange={(event) => setSearchTerm(event.target.value)} placeholder="Search shipments, routes, or status" />
          </label>
          <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
            <option value="all">All statuses</option>
            <option value="Booked">Booked</option>
            <option value="In Transit">In Transit</option>
            <option value="Out for Delivery">Out for Delivery</option>
            <option value="Delivered">Delivered</option>
          </select>
          <select value={serviceFilter} onChange={(event) => setServiceFilter(event.target.value)}>
            <option value="all">All services</option>
            <option value="Express">Express</option>
            <option value="Standard">Standard</option>
            <option value="Priority">Priority</option>
            <option value="Same Day">Same Day</option>
          </select>
        </div>

        <div className="table-wrap">
          <table className="user-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Destination</th>
                <th>Status</th>
                <th>Service</th>
                <th>ETA</th>
              </tr>
            </thead>
            <tbody>
              {filteredShipments.length ? filteredShipments.map((shipment) => (
                <tr key={shipment.id} className={selectedShipment && selectedShipment.id === shipment.id ? 'row-selected' : ''} onClick={() => setSelectedShipmentId(shipment.id)}>
                  <td><strong>{shipment.id}</strong></td>
                  <td>{shipment.destination}</td>
                  <td><StatusBadge status={shipment.status} /></td>
                  <td>{shipment.service}</td>
                  <td>{shipment.eta}</td>
                </tr>
              )) : (
                <tr>
                  <td colSpan="5">
                    <div className="empty-state compact">
                      <PackageCheck size={24} />
                      <h3>No shipment matches your filter.</h3>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {selectedShipment && (
        <aside className="card-block detail-card">
          <div className="card-heading">
            <h2>{selectedShipment.id}</h2>
            <StatusBadge status={selectedShipment.status} />
          </div>
          <div className="detail-list">
            <div>
              <small>Courier</small>
              <strong>{selectedShipment.courier}</strong>
            </div>
            <div>
              <small>Service</small>
              <strong>{selectedShipment.service}</strong>
            </div>
            <div>
              <small>Route</small>
              <strong>{selectedShipment.origin} → {selectedShipment.destination}</strong>
            </div>
            <div>
              <small>ETA</small>
              <strong>{selectedShipment.eta}</strong>
            </div>
            <div>
              <small>Value</small>
              <strong>{selectedShipment.value}</strong>
            </div>
            <div>
              <small>Weight</small>
              <strong>{selectedShipment.weight}</strong>
            </div>
          </div>
          <div className="mini-map">
            <div className="mini-map-connection" />
            <span>{selectedShipment.origin}</span>
            <span>{selectedShipment.destination}</span>
          </div>
          <p className="detail-copy">{selectedShipment.lastUpdate}</p>
        </aside>
      )}
    </div>
  )
}

function TrackingPage({ shipments, selectedShipmentId, setSelectedShipmentId }) {
  const currentShipment = shipments.find((shipment) => shipment.id === selectedShipmentId) || shipments[0]

  return (
    <div className="tracking-layout">
      <div className="card-block wide">
        <div className="card-heading">
          <h2>Tracking</h2>
          <div className="inline-selects">
            {shipments.map((shipment) => (
              <button
                key={shipment.id}
                type="button"
                className={classNames('segment-button', shipment.id === currentShipment.id && 'segment-button-active')}
                onClick={() => setSelectedShipmentId(shipment.id)}
              >
                {shipment.id}
              </button>
            ))}
          </div>
        </div>

        <div className="tracking-panel">
          <div className="tracking-map-preview">
            <div className="map-node start" />
            <div className="map-node end" />
            <div className="map-path" />
            <div className="map-marker" />
          </div>
          <div className="tracking-overview">
            <div>
              <small>Current route</small>
              <strong>{currentShipment.origin} → {currentShipment.destination}</strong>
            </div>
            <div>
              <small>Courier</small>
              <strong>{currentShipment.courier}</strong>
            </div>
            <div>
              <small>Progress</small>
              <strong>{currentShipment.progress}%</strong>
            </div>
          </div>
        </div>

        <div className="timeline-list">
          {currentShipment.timeline.map((step, index) => (
            <div key={step.label} className={classNames('timeline-item', step.complete && 'complete', index === currentShipment.timeline.findIndex((item) => !item.complete) && 'current')}>
              <span className="timeline-dot">{step.complete ? '✓' : index + 1}</span>
              <div>
                <strong>{step.label}</strong>
                <small>{step.time}</small>
              </div>
            </div>
          ))}
        </div>
      </div>

      <aside className="card-block detail-card">
        <div className="card-heading">
          <h2>Latest update</h2>
        </div>
        <div className="status-block">
          <div className="status-pill"><StatusBadge status={currentShipment.status} /></div>
          <div className="status-meta">
            <strong>{currentShipment.status}</strong>
            <span>{currentShipment.eta}</span>
          </div>
        </div>
        <p className="detail-copy">{currentShipment.lastUpdate}</p>
        <div className="detail-list small-list">
          <div>
            <small>Courier contact</small>
            <strong>{currentShipment.contact}</strong>
          </div>
          <div>
            <small>Package weight</small>
            <strong>{currentShipment.weight}</strong>
          </div>
        </div>
      </aside>
    </div>
  )
}

function NotificationsPage({ notifications, setNotifications }) {
  const toggleRead = (id) => {
    setNotifications((current) => current.map((item) => item.id === id ? { ...item, unread: !item.unread } : item))
  }

  return (
    <div className="card-block">
      <div className="card-heading">
        <h2>Notifications</h2>
      </div>
      <div className="notification-list">
        {notifications.map((item) => (
          <div key={item.id} className={classNames('notification-card', item.unread && 'unread')}>
            <div className="notification-icon"><Bell size={17} /></div>
            <div className="notification-copy">
              <h3>{item.title}</h3>
              <p>{item.message}</p>
              <small>{item.time}</small>
            </div>
            <button type="button" className="button button-small button-ghost" onClick={() => toggleRead(item.id)}>
              {item.unread ? 'Mark read' : 'Unread'}
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}

function ProfilePage() {
  return (
    <div className="profile-grid">
      <div className="card-block">
        <div className="card-heading">
          <h2>Profile</h2>
        </div>
        <div className="profile-head">
          <div className="profile-avatar">{userProfile.name.split(' ').map((part) => part[0]).slice(0, 2).join('')}</div>
          <div>
            <h3>{userProfile.name}</h3>
            <span>{userProfile.company}</span>
          </div>
        </div>
        <div className="detail-list">
          <div><small>Email</small><strong>{userProfile.email}</strong></div>
          <div><small>Phone</small><strong>{userProfile.phone}</strong></div>
          <div><small>Location</small><strong>{userProfile.location}</strong></div>
          <div><small>Member since</small><strong>{userProfile.memberSince}</strong></div>
          <div><small>Preferred service</small><strong>{userProfile.preferredService}</strong></div>
        </div>
      </div>

      <div className="card-block">
        <div className="card-heading">
          <h2>Contact & account</h2>
        </div>
        <div className="contact-list">
          <div className="contact-row"><Mail size={15} /> {userProfile.email}</div>
          <div className="contact-row"><Phone size={15} /> {userProfile.phone}</div>
          <div className="contact-row"><Building2 size={15} /> {userProfile.company}</div>
          <div className="contact-row"><Globe size={15} /> {userProfile.location}</div>
        </div>
      </div>
    </div>
  )
}

function SettingsPage() {
  const [preferences, setPreferences] = useState(userSettings)

  const togglePreference = (key) => {
    setPreferences((current) => ({ ...current, [key]: !current[key] }))
  }

  return (
    <div className="card-block">
      <div className="card-heading">
        <h2>Settings</h2>
      </div>
      <div className="settings-list">
        {Object.entries(preferences).map(([key, value]) => (
          <div className="setting-row" key={key}>
            <div>
              <strong>{key.replace(/([A-Z])/g, ' $1').replace(/^./, (letter) => letter.toUpperCase())}</strong>
              <small>Manage notification and delivery preferences.</small>
            </div>
            <button type="button" className={classNames('toggle', value && 'toggle-on')} onClick={() => togglePreference(key)}>
              <span />
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}

export default function UserDashboard() {
  const navigate = useNavigate()
  const location = useLocation()
  const { logout, user } = useAuth()
  const [shipments, setShipments] = useState(mockShipments)
  const [notifications, setNotifications] = useState(initialNotifications)
  const [selectedShipmentId, setSelectedShipmentId] = useState(mockShipments[0].id)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [serviceFilter, setServiceFilter] = useState('all')
  useEffect(() => {
    shipmentApi.list().then(({ shipments: rows }) => {
      if (!rows?.length) return
      setShipments(rows.map((item) => ({
        ...item, id: item.trackingId, value: `₹${item.value || item.price || 0}`,
        weight: `${item.weight || 0} kg`, eta: item.estimatedDelivery ? new Date(item.estimatedDelivery).toLocaleString() : 'Pending',
        courier: item.courier?.name || 'Pending assignment', contact: item.courier?.phone || 'Not assigned',
        progress: item.status === 'Delivered' ? 100 : 35, timeline: (item.events || []).map((event) => ({ label: event.status, time: new Date(event.timestamp).toLocaleTimeString(), complete: true })),
        lastUpdate: item.events?.at(-1)?.note || 'Shipment booked.'
      })))
    }).catch(() => {})
    api('/users/me/notifications').then(({ notifications: rows }) => rows?.length && setNotifications(rows.map((item) => ({ ...item, unread: !item.read, time: new Date(item.createdAt).toLocaleString() })))).catch(() => {})
  }, [])

  if (location.pathname === '/dashboard' || location.pathname === '/dashboard/') {
    return <Navigate to="/dashboard/overview" replace />
  }

  return (
    <div className="user-shell">
      <aside className="user-sidebar">
        <div className="sidebar-brand">
          <div className="brand-mark"><Box size={16} /></div>
          <span>SmartCourier</span>
        </div>

        <div className="sidebar-section-label">Workspace</div>
        <nav className="sidebar-nav">
          {navItems.map(({ label, to, icon: Icon, exact }) => (
            <NavLink key={to} to={to} end={exact} className={({ isActive }) => classNames(isActive && 'active')}>
              <Icon size={16} />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-logout">
          <button type="button" onClick={() => { logout(); navigate('/login') }}>
            <LogOut size={15} />
            <span>Log out</span>
          </button>
        </div>
      </aside>

      <main className="user-content">
        <header className="user-topbar">
          <div>
            <span className="eyebrow"><i /> CUSTOMER COMMAND</span>
            <h1>Welcome back, {(user?.name || userProfile.name).split(' ')[0]}.</h1>
          </div>
          <div className="topbar-actions">
            <button type="button" className="button button-small button-ghost">
              <Menu size={14} />
              Quick menu
            </button>
            <button type="button" className="button button-small">
              <Sparkles size={14} />
              Upgrade plan
            </button>
          </div>
        </header>

        <Routes>
          <Route path="overview" element={<OverviewPage shipments={shipments} />} />
          <Route path="" element={<OverviewPage shipments={shipments} />} />
          <Route path="booking" element={<BookingPage shipments={shipments} setShipments={setShipments} selectedShipmentId={selectedShipmentId} setSelectedShipmentId={setSelectedShipmentId} navigate={navigate} />} />
          <Route path="shipments" element={<ShipmentsPage shipments={shipments} selectedShipmentId={selectedShipmentId} setSelectedShipmentId={setSelectedShipmentId} searchTerm={searchTerm} setSearchTerm={setSearchTerm} statusFilter={statusFilter} setStatusFilter={setStatusFilter} serviceFilter={serviceFilter} setServiceFilter={setServiceFilter} />} />
          <Route path="tracking" element={<TrackingPage shipments={shipments} selectedShipmentId={selectedShipmentId} setSelectedShipmentId={setSelectedShipmentId} />} />
          <Route path="notifications" element={<NotificationsPage notifications={notifications} setNotifications={setNotifications} />} />
          <Route path="profile" element={<ProfilePage />} />
          <Route path="settings" element={<SettingsPage />} />
        </Routes>
      </main>
    </div>
  )
}
