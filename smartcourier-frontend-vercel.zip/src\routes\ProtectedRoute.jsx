import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function ProtectedRoute({ children, allowedRole, allowPending = false }) {
  const { isAuthenticated, role, pendingUser } = useAuth()
  const location = useLocation()
  if (!isAuthenticated && !(allowPending && pendingUser)) return <Navigate to="/login" state={{ from: location }} replace />
  if (allowedRole && role !== allowedRole) return <Navigate to={role === 'admin' ? '/admin/dashboard' : role === 'courier' ? '/courier/dashboard' : '/dashboard'} replace />
  return children
}
