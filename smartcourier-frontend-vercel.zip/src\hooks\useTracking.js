import { useEffect, useState } from 'react'

export function useTracking(initialShipment = null) {
  const [shipment, setShipment] = useState(initialShipment)
  const [connected, setConnected] = useState(true)

  useEffect(() => {
    const handleOffline = () => setConnected(false)
    const handleOnline = () => setConnected(true)
    window.addEventListener('offline', handleOffline)
    window.addEventListener('online', handleOnline)
    return () => {
      window.removeEventListener('offline', handleOffline)
      window.removeEventListener('online', handleOnline)
    }
  }, [])

  return { shipment, setShipment, connected }
}
