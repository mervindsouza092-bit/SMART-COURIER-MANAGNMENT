import { Activity, Bot, BrainCircuit, Gauge, ShieldCheck, Sparkles, TrendingUp } from 'lucide-react'

const metrics = [
  { label: 'AI STATUS', value: 'ONLINE', icon: Bot },
  { label: 'ETA PREDICTIONS', value: '128', icon: Gauge },
  { label: 'SMART RECOMMENDATIONS', value: '43', icon: BrainCircuit },
  { label: 'ACTIVE ALERTS', value: '7', icon: ShieldCheck },
  { label: 'ANOMALIES', value: '3', icon: Activity },
]

const insights = [
  {
    title: 'Delivery Insight',
    text: 'Express shipments are experiencing higher delays during evening hours.',
    tone: 'cyan',
  },
  {
    title: 'Courier Insight',
    text: 'Average delivery time has improved over the last 7 days.',
    tone: 'purple',
  },
  {
    title: 'Operations Insight',
    text: 'A high concentration of active shipments is currently present in one delivery zone.',
    tone: 'green',
  },
]

export default function AdminAICommandCenter() {
  return (
    <div className="page-shell analytics-shell">
      <div className="section-heading" style={{ marginBottom: 26 }}>
        <div className="eyebrow"><i /> SMART COURIER AI</div>
        <h2>AI operations center</h2>
      </div>

      <div className="ai-metric-grid">
        {metrics.map(({ label, value, icon: Icon }) => (
          <article key={label} className="ai-metric-card">
            <div className="ai-metric-icon"><Icon size={18} /></div>
            <div>
              <span>{label}</span>
              <strong>{value}</strong>
            </div>
          </article>
        ))}
      </div>

      <div className="ai-core-panel">
        <div className="ai-core-ring">
          <div className="ai-core-inner">
            <Sparkles size={30} />
          </div>
        </div>
        <div className="ai-core-copy">
          <span className="eyebrow"><i /> PREDICTIVE MODELS</span>
          <h3>AI recommendation engine</h3>
          <p>
            The platform evaluates courier availability, route density, historical completion rates,
            and time-sensitive delivery pressure to suggest operational recommendations.
          </p>
        </div>
      </div>

      <div className="analytics-grid info-grid">
        {insights.map((insight) => (
          <article className={`info-banner ${insight.tone}`} key={insight.title}>
            <span className="eyebrow"><i /> {insight.title.toUpperCase()}</span>
            <h3>{insight.title}</h3>
            <p>{insight.text}</p>
          </article>
        ))}
      </div>
    </div>
  )
}
