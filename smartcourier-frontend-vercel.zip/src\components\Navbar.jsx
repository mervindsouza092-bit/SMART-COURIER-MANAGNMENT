import { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { MapPin, Menu, Package, X } from 'lucide-react'

const links = [['Home', '/'], ['Features', '/#features'], ['Tracking', '/tracking'], ['Services', '/#services'], ['How It Works', '/#how-it-works'], ['About', '/#about']]

export default function Navbar() {
  const [open, setOpen] = useState(false)
  return <header className="navbar">
    <Link className="brand" to="/" onClick={() => setOpen(false)}><span className="brand-mark"><Package size={18} /><MapPin size={12} /></span><span>SMART <b>COURIER</b></span></Link>
    <nav className={open ? 'nav-links open' : 'nav-links'}>{links.map(([label, to]) => <NavLink key={label} to={to} onClick={() => setOpen(false)}>{label}</NavLink>)}<span className="nav-actions"><Link className="text-link" to="/login">LOGIN</Link><Link className="button button-small" to="/register">GET STARTED <span>↗</span></Link></span></nav>
    <button className="menu-toggle" onClick={() => setOpen(!open)} aria-label="Toggle navigation">{open ? <X /> : <Menu />}</button>
  </header>
}
