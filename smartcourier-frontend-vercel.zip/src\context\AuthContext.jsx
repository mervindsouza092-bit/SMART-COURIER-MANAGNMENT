import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { authApi } from '../services/api'

const AuthContext = createContext(null)
const DEMO_ACCOUNTS = {
  user: { email: 'user@smartcourier.demo', password: 'user12345', name: 'Demo User' },
  admin: { email: 'admin@smartcourier.demo', password: 'admin1234', name: 'Demo Admin' },
  courier: { email: 'courier@smartcourier.demo', password: 'courier123', name: 'Demo Courier' },
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem('smartCourierUser') || 'null'))
  const [role, setRoleState] = useState(() => localStorage.getItem('smartCourierRole') || '')
  const [isAuthenticated, setAuthenticated] = useState(() => Boolean(localStorage.getItem('smartCourierToken')))
  const [pendingUser, setPendingUser] = useState(null)

  useEffect(() => { if (localStorage.getItem('smartCourierToken')) authApi.me().then(({ user: current }) => { setUser(current); setRoleState(current.role) }).catch(logout) }, [])
  const login = async (email, password) => {
    try {
      const data = await authApi.login({ email, password })
      localStorage.setItem('smartCourierToken', data.token)
      setUser(data.user)
      setPendingUser(data.user)
      setRoleState(data.user.role)
      setAuthenticated(true)
      return { ok: true }
    } catch (error) {
      const demoAccount = Object.entries(DEMO_ACCOUNTS).find(([, account]) => account.email === email && account.password === password)
      if (!demoAccount) return { ok: false, message: error.message }

      const [demoRole, account] = demoAccount
      const demoUser = { id: `demo-${demoRole}`, name: account.name, email: account.email, role: demoRole }
      setUser(demoUser)
      setPendingUser(demoUser)
      setRoleState(demoRole)
      setAuthenticated(true)
      localStorage.setItem('smartCourierUser', JSON.stringify(demoUser))
      localStorage.setItem('smartCourierRole', demoRole)
      localStorage.setItem('smartCourierAuthenticated', 'true')
      return { ok: true }
    }
  }
  const setRole = (nextRole) => {
    const nextUser = pendingUser || user
    const effectiveRole = nextUser?.role || nextRole
    setRoleState(effectiveRole)
    setUser(nextUser)
    setAuthenticated(true)
    localStorage.setItem('smartCourierRole', effectiveRole)
    localStorage.setItem('smartCourierUser', JSON.stringify(nextUser))
    localStorage.setItem('smartCourierAuthenticated', 'true')
  }
  const register = async (details) => { try { await authApi.register({ name: details.name, email: details.email, phone: details.phone, password: details.password, role: details.role }); return { ok: true } } catch (error) { return { ok: false, message: error.message } } }
  const logout = () => {
    setUser(null); setRoleState(''); setAuthenticated(false); setPendingUser(null)
    localStorage.removeItem('smartCourierUser')
    localStorage.removeItem('smartCourierRole')
    localStorage.removeItem('smartCourierAuthenticated')
    localStorage.removeItem('smartCourierToken')
  }
  const value = useMemo(() => ({ user, role, isAuthenticated, pendingUser, login, setRole, register, logout, demoAccounts: DEMO_ACCOUNTS }), [user, role, isAuthenticated, pendingUser])
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  return useContext(AuthContext)
}
