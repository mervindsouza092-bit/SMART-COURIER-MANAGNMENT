import { ArrowUpRight } from 'lucide-react'
import { Link } from 'react-router-dom'

export default function Button({ children, to = '#', variant = 'primary' }) {
  return <Link className={`button ${variant}`} to={to}>{children}<ArrowUpRight size={15} /></Link>
}
