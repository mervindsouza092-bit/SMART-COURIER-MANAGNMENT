import { useEffect, useState } from 'react'
import { CreditCard, Download, ShieldCheck, Wallet } from 'lucide-react'
import { api } from '../services/api'

export default function PaymentsPage() {
  const [payments, setPayments] = useState([])
  const [summary, setSummary] = useState({ total: 0, count: 0 })

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await api('/payments/history')
        setPayments(response.payments || [])
        setSummary({ total: (response.payments || []).reduce((sum, payment) => sum + Number(payment.amount || 0), 0), count: (response.payments || []).length })
      } catch (error) {
        console.error(error)
      }
    }
    fetchData()
  }, [])

  return (
    <section className="page-shell shell-space">
      <div className="section-heading"><span className="eyebrow"><i /> PAYMENT HISTORY</span><h2>Secure checkout</h2></div>
      <div className="stats-grid">
        <article className="kpi-card"><div className="kpi-icon purple"><Wallet size={18} /></div><strong>₹{summary.total.toLocaleString('en-IN')}</strong><span>Total paid</span></article>
        <article className="kpi-card"><div className="kpi-icon cyan"><CreditCard size={18} /></div><strong>{summary.count}</strong><span>Transactions</span></article>
        <article className="kpi-card"><div className="kpi-icon green"><ShieldCheck size={18} /></div><strong>Protected</strong><span>Secure gateway</span></article>
      </div>

      <div className="card-block panel-glow">
        <div className="card-heading"><h3>Payment history</h3></div>
        <div className="table-wrap">
          <table className="user-table">
            <thead><tr><th>Payment ID</th><th>Shipment</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>
              {payments.length ? payments.map((payment) => (
                <tr key={payment._id || payment.orderId}><td>{payment.orderId || payment.paymentId}</td><td>{payment.shipment || 'SC-2026-94821'}</td><td>₹{Number(payment.amount || 0).toLocaleString('en-IN')}</td><td><span className="status-badge status-delivered">{payment.status}</span></td><td><button className="button button-small button-ghost"><Download size={12} /> RECEIPT</button></td></tr>
              )) : <tr><td colSpan="5">No payments yet. Complete a booking to see payment history.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  )
}
