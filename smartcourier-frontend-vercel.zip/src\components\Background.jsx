import { motion } from 'framer-motion'

export default function Background() {
  return <div className="ambient-bg" aria-hidden="true">
    <div className="grid-lines" />
    <div className="orb orb-one" />
    <div className="orb orb-two" />
    <div className="scan-line" />
    {[1, 2, 3, 4, 5, 6].map((dot) => (
      <motion.i
        key={dot}
        className={`particle p-${dot}`}
        animate={{ y: [0, -16, 0], opacity: [0.2, 0.8, 0.2] }}
        transition={{
          duration: 5.2 + dot,
          repeat: Infinity,
          ease: 'easeInOut',
          repeatType: 'mirror',
          delay: dot * 0.28,
        }}
      />
    ))}
  </div>
}
