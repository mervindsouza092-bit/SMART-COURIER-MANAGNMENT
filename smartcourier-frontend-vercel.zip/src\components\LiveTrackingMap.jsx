import { motion } from 'framer-motion'
import { Crosshair, MapPin, Navigation, Radio, Truck } from 'lucide-react'

export default function LiveTrackingMap({ shipment, courierLocation, mapReady = false }) {
  const pickup = shipment?.origin || 'Pickup'
  const destination = shipment?.destination || 'Destination'
  const currentPosition = courierLocation || { latitude: 19.457, longitude: 72.812 }

  return (
    <div className="tracking-map-shell">
      <div className="map-surface">
        <div className="map-grid" />
        {!mapReady ? (
          <div className="fallback-map-panel">
            <div className="fallback-badge"><Radio size={12} /> LIVE TRACKING</div>
            <h3>Live map temporarily unavailable.</h3>
            <p>Location updates are still being received.</p>
            <div className="fallback-coords">
              <span>Lat {currentPosition.latitude?.toFixed(4) || '19.4570'}</span>
              <span>Lng {currentPosition.longitude?.toFixed(4) || '72.8120'}</span>
            </div>
            <div className="live-status-indicator"><span className="live-dot" /> LIVE</div>
          </div>
        ) : null}

        <svg className="route-svg" viewBox="0 0 800 420" preserveAspectRatio="none">
          <path d="M110 290 C230 230 230 120 350 130 S560 280 690 100" className="route-shadow" />
          <motion.path d="M110 290 C230 230 230 120 350 130 S560 280 690 100" className="route-path" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 2.3, ease: 'easeInOut' }} />
        </svg>

        <div className="route-label pickup-label">{pickup}</div>
        <div className="route-label destination-label">{destination}</div>
        <motion.div className="map-pin pin-start" animate={{ y: [0, -7, 0] }} transition={{ repeat: Infinity, duration: 2.2 }}><MapPin size={18} /></motion.div>
        <motion.div className="map-pin pin-end" animate={{ scale: [1, 1.15, 1] }} transition={{ repeat: Infinity, duration: 2.4 }}><Crosshair size={18} /></motion.div>
        <motion.div className="courier-marker" animate={{ x: [0, 8, 0], y: [0, -6, 0] }} transition={{ duration: 2.8, repeat: Infinity, ease: 'easeInOut' }}>
          <Truck size={18} />
        </motion.div>
        <div className="map-readout">
          <span><Radio size={11} /> LIVE NETWORK</span>
          <b>{shipment?.trackingId || 'SC-2026-94821'}</b>
          <small>LAST UPDATE {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</small>
        </div>
      </div>
      <div className="tracking-metrics">
        <div><Navigation size={14} /> {shipment?.status || 'In Transit'}</div>
        <div><MapPin size={14} /> Courier online</div>
      </div>
    </div>
  )
}
