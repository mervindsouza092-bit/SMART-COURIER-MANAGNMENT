﻿import { AnimatePresence, motion } from 'framer-motion'
import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import Background from './components/Background'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import ErrorBoundary from './components/ErrorBoundary'
import Home from './pages/Home'
import Login from './pages/Login'
import Register from './pages/Register'
import SelectRole from './pages/SelectRole'
import ForgotPassword from './pages/ForgotPassword'
import ResetPassword from './pages/ResetPassword'
import Dashboard from './pages/Dashboard'
import UserDashboard from './pages/UserDashboard'
import ProtectedRoute from './routes/ProtectedRoute'
import { pageTransition } from './animations/variants'
import AdminCommandCenter from './pages/AdminCommandCenter'
import AdminAICommandCenter from './pages/AdminAICommandCenter'
import AdminAnalytics from './pages/AdminAnalytics'
import AdminAlertsPage from './pages/AdminAlertsPage'
import AdminSystemHealth from './pages/AdminSystemHealth'
import LiveTrackingPage from './pages/LiveTrackingPage'
import PaymentsPage from './pages/PaymentsPage'

export default function App() {
  const location = useLocation()
  const isAdmin = location.pathname.startsWith('/admin')

  return (
    <ErrorBoundary>
      <>
        <Background />
        {!isAdmin && <Navbar />}
        <AnimatePresence mode="wait">
          <motion.main key={location.pathname} {...pageTransition}>
            <Routes location={location}>
              <Route path="/" element={<Home />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/select-role" element={<ProtectedRoute allowPending><SelectRole /></ProtectedRoute>} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/reset-password" element={<ResetPassword />} />
              <Route path="/tracking" element={<LiveTrackingPage />} />
              <Route path="/track/:trackingId" element={<LiveTrackingPage />} />
              <Route path="/payments" element={<ProtectedRoute allowedRole="user"><PaymentsPage /></ProtectedRoute>} />
              <Route path="/dashboard/*" element={<ProtectedRoute allowedRole="user"><UserDashboard /></ProtectedRoute>} />
              <Route path="/book-courier" element={<Navigate to="/dashboard/booking" replace />} />
              <Route path="/shipments" element={<Navigate to="/dashboard/shipments" replace />} />
              <Route path="/shipments/:id" element={<Navigate to="/dashboard/shipments" replace />} />
              <Route path="/notifications" element={<Navigate to="/dashboard/notifications" replace />} />
              <Route path="/profile" element={<Navigate to="/dashboard/profile" replace />} />
              <Route path="/settings" element={<Navigate to="/dashboard/settings" replace />} />
              <Route path="/admin/ai-center" element={<ProtectedRoute allowedRole="admin"><AdminAICommandCenter /></ProtectedRoute>} />
              <Route path="/admin/analytics" element={<ProtectedRoute allowedRole="admin"><AdminAnalytics /></ProtectedRoute>} />
              <Route path="/admin/alerts" element={<ProtectedRoute allowedRole="admin"><AdminAlertsPage /></ProtectedRoute>} />
              <Route path="/admin/system-health" element={<ProtectedRoute allowedRole="admin"><AdminSystemHealth /></ProtectedRoute>} />
              <Route path="/admin/shipments/:id" element={<ProtectedRoute allowedRole="admin"><AdminCommandCenter /></ProtectedRoute>} />
              <Route path="/admin/users/:id" element={<ProtectedRoute allowedRole="admin"><AdminCommandCenter /></ProtectedRoute>} />
              <Route path="/admin/couriers/:id" element={<ProtectedRoute allowedRole="admin"><AdminCommandCenter /></ProtectedRoute>} />
              <Route path="/admin/:section" element={<ProtectedRoute allowedRole="admin"><AdminCommandCenter /></ProtectedRoute>} />
              <Route path="/courier/dashboard" element={<ProtectedRoute allowedRole="courier"><Dashboard kind="courier" /></ProtectedRoute>} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </motion.main>
        </AnimatePresence>
        {!isAdmin && <Footer />}
      </>
    </ErrorBoundary>
  )
}

