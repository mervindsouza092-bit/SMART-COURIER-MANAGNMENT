import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import AuthShell from '../components/auth/AuthShell'
import Input from '../components/common/Input'
import Loading from '../components/common/Loading'
import PasswordStrength from '../components/auth/PasswordStrength'
import AuthModal from '../components/auth/AuthModal'
import { useAuth } from '../context/AuthContext'

export default function Register() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '', confirm: '', role: 'user' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const { register } = useAuth()
  const navigate = useNavigate()
  const update = (key) => (event) => { setForm({ ...form, [key]: event.target.value }); setError('') }
  const submit = async (event) => { event.preventDefault(); if (!form.name || !form.email || !/^\S+@\S+\.\S+$/.test(form.email)) return setError('Please complete the required fields with a valid email.'); if (form.phone && !/^[+()\d\s-]{7,}$/.test(form.phone)) return setError('Please enter a valid phone number.'); if (form.password.length < 8) return setError('Password must contain at least 8 characters.'); if (form.password !== form.confirm) return setError('Your passwords do not match.'); setLoading(true); const result = await register(form); setLoading(false); if (!result.ok) return setError(result.message); setSuccess(true) }
  return <AuthShell eyebrow="NEW OPERATIONS" title={<>CREATE YOUR<br /><span>ACCOUNT.</span></>}><h2>JOIN THE NETWORK</h2><p className="auth-subtitle">Join the next generation of intelligent logistics.</p><form onSubmit={submit} className="register-form"><Input label="FULL NAME" value={form.name} onChange={update('name')} placeholder="Your name" /><Input label="EMAIL ADDRESS" value={form.email} onChange={update('email')} placeholder="you@company.com" /><div className="form-two"><Input label="PHONE NUMBER" value={form.phone} onChange={update('phone')} required={false} placeholder="+91 00000 00000" /><label className="auth-field"><span>ACCESS TYPE</span><select value={form.role} onChange={update('role')}><option value="user">USER</option><option value="courier">COURIER</option></select></label></div><Input label="PASSWORD" type="password" value={form.password} onChange={update('password')} placeholder="Minimum 8 characters" /><PasswordStrength password={form.password} /><Input label="CONFIRM PASSWORD" type="password" value={form.confirm} onChange={update('confirm')} placeholder="Repeat your password" />{error && <div className="form-error">{error}</div>}<button className="button auth-submit" disabled={loading}>{loading ? <Loading label="CREATING ACCOUNT..." /> : 'CREATE SMART ACCOUNT ↗'}</button></form><p className="auth-switch">Already have an account? <Link to="/login">LOGIN TO SYSTEM</Link></p>{success && <AuthModal title="ACCOUNT CREATED" text="Welcome to Smart Courier. Redirecting you to login." action={<button className="button" onClick={() => navigate('/login')}>CONTINUE ↗</button>} />}</AuthShell>
}
