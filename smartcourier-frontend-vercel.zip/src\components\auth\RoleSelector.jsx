import { motion } from 'framer-motion'
import { Shield, Truck, UserRound } from 'lucide-react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'

const roles = [['user', UserRound, 'USER', 'Book, manage and track your deliveries.'], ['courier', Truck, 'COURIER', 'Manage assigned deliveries and update shipment status.'], ['admin', Shield, 'ADMIN', 'Manage the complete courier network.']]
export default function RoleSelector() {
  const [selected, setSelected] = useState('')
  const { setRole } = useAuth()
  const navigate = useNavigate()
  const continueRole = () => { if (!selected) return; setRole(selected); navigate(selected === 'admin' ? '/admin/dashboard' : selected === 'courier' ? '/courier/dashboard' : '/dashboard') }
  return <div className="role-selector"><span className="eyebrow"><i />ACCESS PROTOCOL</span><h1>SELECT ACCESS LEVEL</h1><p>Choose how you want to access Smart Courier.</p><div className="role-grid">{roles.map(([id, Icon, name, description]) => <motion.button type="button" className={`role-card ${selected === id ? 'selected' : ''}`} whileHover={{ y: -7, rotateX: 3 }} onClick={() => setSelected(id)} key={id}><Icon /><b>{name}</b><span>{description}</span>{selected === id && <small>✓ SELECTED</small>}</motion.button>)}</div><button className="button role-continue" disabled={!selected} onClick={continueRole}>CONTINUE ↗</button></div>
}
