import { useEffect, useMemo, useState } from 'react'
import { Activity, Clock3, MapPinned, PackageCheck, Radio, ShieldCheck, Truck } from 'lucide-react'
import { Link, useParams } from 'react-router-dom'
import { api } from '../services/api'
import { useSocket } from '../hooks/useSocket'
import LiveTrackingMap from '../components/LiveTrackingMap'

const DEFAULT_SHIPMENT = {
  trackingId: 'SC-2026-94821',
  status: 'In Transit',
  origin: 'Mumbai',
  destination: 'Pune',
  service: 'Express',
  courier: { name: 'Arjun Nair', phone: '+91 98765 43210' },
  eta: 'Today, 5:30 PM',
  currentLocation: { latitude: 19.457, longitude: 72.812 },
}

export default function LiveTrackingPage() {
  const { trackingId } = useParams()
  const [shipment, setShipment] = useState(DEFAULT_SHIPMENT)
  const [liveLocation, setLiveLocation] = useState(DEFAULT_SHIPMENT.currentLocation)
  const [statusText, setStatusText] = useState('Reconnecting to Smart Courier Network...')
  const { socket, connected } = useSocket()

  useEffect(() => {
    const fetchShipment = async () => {
      try {
        const response = await api(`/shipments/track/${trackingId || DEFAULT_SHIPMENT.trackingId}`)
        const current = response.shipment || DEFAULT_SHIPMENT
        setShipment(current)
        if (current.currentLocation) setLiveLocation(current.currentLocation)
      } catch (error) {
        console.error(error)
      }
    }
    fetchShipment()
  }, [trackingId])

  useEffect(() => {
    if (!socket) return undefined
    const onShipmentUpdate = (payload) => {
      if (payload.trackingId === shipment.trackingId || payload.shipmentId === shipment._id) {
        setShipment((current) => ({ ...current, status: payload.status, lastUpdated: payload.timestamp }))
      }
    }
    const onLocationUpdate = (payload) => {
      if (payload.trackingId === shipment.trackingId || payload.shipmentId === shipment._id) {
        setLiveLocation(payload.location)
        setStatusText('● Live connection restored')
      }
    }
    socket.on('shipment:statusUpdated', onShipmentUpdate)
    socket.on('courier:locationUpdated', onLocationUpdate)
    socket.on('connect', () => setStatusText('● Live connection restored'))
    socket.on('disconnect', () => setStatusText('Reconnecting to Smart Courier Network...'))

    return () => {
      socket.off('shipment:statusUpdated', onShipmentUpdate)
      socket.off('courier:locationUpdated', onLocationUpdate)
    }
  }, [socket, shipment.trackingId, shipment._id])

  const timeline = useMemo(() => [
    { label: 'Booking Confirmed', complete: true, time: '10:20 AM' },
    { label: 'Courier Assigned', complete: true, time: '10:35 AM' },
    { label: 'Picked Up', complete: true, time: '12:15 PM' },
    { label: 'In Transit', complete: true, time: '01:40 PM' },
    { label: 'Out for Delivery', complete: false, time: 'Pending' },
    { label: 'Delivered', complete: false, time: 'Pending' }
  ], [])

  return (
    <section className="page-shell tracking-page shell-space">
      <div className="section-heading"><span className="eyebrow"><i /> LIVE DELIVERY NETWORK</span><h2>Shipment tracking</h2></div>
      <div className="tracking-topbar">
        <div>
          <span className="muted-label">Tracking ID</span>
          <strong>{shipment.trackingId}</strong>
        </div>
        <div>
          <span className="muted-label">Status</span>
          <strong className="status-pill status-in-transit">{shipment.status}</strong>
        </div>
        <div>
          <span className="muted-label">Connection</span>
          <strong className={connected ? 'online-dot' : 'offline-dot'}>{connected ? '● LIVE' : '○ OFFLINE'}</strong>
        </div>
      </div>

      <div className="tracking-grid">
        <div className="card-block panel-glow">
          <div className="card-heading"><h3>Shipment information</h3><span className="status-badge status-in-transit">{shipment.status}</span></div>
          <div className="shipment-details-grid">
            <div><span>Courier</span><strong>{shipment.courier?.name || 'Assigned courier'}</strong></div>
            <div><span>Contact</span><strong>{shipment.courier?.phone || '+91 98765 43210'}</strong></div>
            <div><span>Pickup</span><strong>{shipment.origin}</strong></div>
            <div><span>Destination</span><strong>{shipment.destination}</strong></div>
            <div><span>Delivery type</span><strong>{shipment.service || 'Express'}</strong></div>
            <div><span>Estimated arrival</span><strong>{shipment.eta || 'Today, 5:30 PM'}</strong></div>
          </div>
          <div className="live-summary-row">
            <div><PackageCheck size={16} /> Secure package</div>
            <div><ShieldCheck size={16} /> Verified route</div>
            <div><Clock3 size={16} /> {statusText}</div>
          </div>
        </div>

        <div className="card-block panel-glow">
          <div className="card-heading"><h3>Live route</h3><span className="muted-label">{shipment.status}</span></div>
          <LiveTrackingMap shipment={shipment} courierLocation={liveLocation} mapReady={false} />
        </div>
      </div>

      <div className="tracking-grid lower-grid">
        <div className="card-block panel-glow">
          <div className="card-heading"><h3>Delivery timeline</h3></div>
          <div className="timeline-list">
            {timeline.map((step, index) => (
              <div key={step.label} className={`timeline-item ${step.complete ? 'complete' : ''} ${index === 3 ? 'active' : ''}`}>
                <div className="timeline-dot" /><div><strong>{step.label}</strong><small>{step.time}</small></div>
              </div>
            ))}
          </div>
        </div>
        <div className="card-block panel-glow">
          <div className="card-heading"><h3>Live courier update</h3></div>
          <div className="mini-stat-grid">
            <div><Radio size={16} /> <span>Current location</span><strong>{liveLocation.latitude?.toFixed(3) || '19.457'}, {liveLocation.longitude?.toFixed(3) || '72.812'}</strong></div>
            <div><MapPinned size={16} /> <span>Nearest checkpoint</span><strong>Midway hub</strong></div>
            <div><Truck size={16} /> <span>Courier status</span><strong>On route</strong></div>
            <div><Activity size={16} /> <span>ETA adjust</span><strong>2 min variance</strong></div>
          </div>
          <Link to="/dashboard/shipments" className="button button-ghost">VIEW SHIPMENT</Link>
        </div>
      </div>
    </section>
  )
}
