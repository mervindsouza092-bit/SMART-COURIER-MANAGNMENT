import { io } from 'socket.io-client'

const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || 'http://localhost:5000'

export function createSocketConnection(token) {
  const socket = io(SOCKET_URL, {
    autoConnect: false,
    transports: ['websocket'],
    auth: { token },
  })
  return socket
}

export function listenForShipmentUpdates(socket, handler) {
  if (!socket) return undefined
  socket.on('shipment:statusUpdated', handler)
  return () => socket.off('shipment:statusUpdated', handler)
}

export function listenForLocationUpdates(socket, handler) {
  if (!socket) return undefined
  socket.on('courier:locationUpdated', handler)
  return () => socket.off('courier:locationUpdated', handler)
}

export function listenForNotifications(socket, handler) {
  if (!socket) return undefined
  socket.on('notification:new', handler)
  return () => socket.off('notification:new', handler)
}
