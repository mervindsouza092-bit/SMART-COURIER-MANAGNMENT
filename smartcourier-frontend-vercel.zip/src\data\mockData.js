﻿const mockShipments = [
  {
    id: 'SC-20491',
    status: 'In Transit',
    statusClass: 'status-in-transit',
    service: 'Express',
    origin: 'New York, NY',
    destination: 'Boston, MA',
    eta: 'Today, 4:40 PM',
    progress: 72,
    value: '₹2,980',
    weight: '4.8 kg',
    courier: 'Ava Brooks',
    contact: '+1 (415) 551-2049',
    lastUpdate: 'Cargo is on the interstate route toward the Northeast corridor.',
    timeline: [
      { label: 'Booked', time: '08:15', complete: true },
      { label: 'Pickup', time: '09:05', complete: true },
      { label: 'In Transit', time: '11:20', complete: true },
      { label: 'Hub Scan', time: '14:10', complete: false },
      { label: 'Delivery', time: '16:40', complete: false }
    ]
  },
  {
    id: 'SC-20488',
    status: 'Out for Delivery',
    statusClass: 'status-out-for-delivery',
    service: 'Standard',
    origin: 'Austin, TX',
    destination: 'Dallas, TX',
    eta: 'Today, 1:25 PM',
    progress: 89,
    value: '₹1,480',
    weight: '2.6 kg',
    courier: 'Nina Patel',
    contact: '+1 (512) 204-1188',
    lastUpdate: 'The courier is finalizing the last mile and expects a doorstep delivery soon.',
    timeline: [
      { label: 'Booked', time: '06:30', complete: true },
      { label: 'Pickup', time: '07:10', complete: true },
      { label: 'In Transit', time: '08:25', complete: true },
      { label: 'Hub Scan', time: '10:45', complete: true },
      { label: 'Delivery', time: '13:25', complete: false }
    ]
  },
  {
    id: 'SC-20472',
    status: 'Delivered',
    statusClass: 'status-delivered',
    service: 'Priority',
    origin: 'Seattle, WA',
    destination: 'Portland, OR',
    eta: 'Delivered on Sep 16',
    progress: 100,
    value: '₹2,140',
    weight: '1.9 kg',
    courier: 'Marco Ellis',
    contact: '+1 (206) 774-1921',
    lastUpdate: 'Delivered and signed by the recipient.',
    timeline: [
      { label: 'Booked', time: '09:00', complete: true },
      { label: 'Pickup', time: '09:25', complete: true },
      { label: 'In Transit', time: '10:55', complete: true },
      { label: 'Hub Scan', time: '12:35', complete: true },
      { label: 'Delivery', time: '14:10', complete: true }
    ]
  },
  {
    id: 'SC-20461',
    status: 'Booked',
    statusClass: 'status-booked',
    service: 'Same Day',
    origin: 'Chicago, IL',
    destination: 'Milwaukee, WI',
    eta: 'Tomorrow, 9:00 AM',
    progress: 14,
    value: '₹1,760',
    weight: '5.2 kg',
    courier: 'Pending assignment',
    contact: '+1 (312) 829-4119',
    lastUpdate: 'Awaiting courier assignment for the morning slots.',
    timeline: [
      { label: 'Booked', time: 'Today', complete: true },
      { label: 'Pickup', time: 'Pending', complete: false },
      { label: 'In Transit', time: 'Pending', complete: false },
      { label: 'Hub Scan', time: 'Pending', complete: false },
      { label: 'Delivery', time: 'Pending', complete: false }
    ]
  }
]

const notifications = [
  { id: 1, title: 'Shipment update', message: 'SC-20491 has left the regional hub and is moving toward the final mile.', time: '2 min ago', unread: true, kind: 'info' },
  { id: 2, title: 'Courier assigned', message: 'Ava Brooks has been assigned to your latest booking and will contact you soon.', time: '18 min ago', unread: true, kind: 'success' },
  { id: 3, title: 'Delivery reminder', message: 'Please ensure access to the delivery address before 4:30 PM.', time: '1 hour ago', unread: false, kind: 'warning' },
  { id: 4, title: 'Billing summary', message: 'Your invoice for the September batch is ready to review in billing.', time: 'Yesterday', unread: false, kind: 'info' }
]

const userProfile = {
  name: 'Maya Thompson',
  email: 'maya.thompson@smartcourier.app',
  phone: '+1 (415) 551-2049',
  location: 'San Francisco, CA',
  memberSince: 'January 2024',
  preferredService: 'Express Priority',
  company: 'Northstar Studio'
}

const userSettings = {
  emailAlerts: true,
  pushAlerts: true,
  smsTracking: false,
  autoAssign: true,
  maintainAddressBook: true,
  deliveryWindowText: true
}

export { mockShipments, notifications, userProfile, userSettings }
