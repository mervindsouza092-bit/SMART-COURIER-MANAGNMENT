import AuthShell from '../components/auth/AuthShell'
import RoleSelector from '../components/auth/RoleSelector'
export default function SelectRole() {
  return <AuthShell eyebrow="IDENTITY HANDSHAKE" title={<>YOUR NETWORK.<br /><span>YOUR ACCESS.</span></>}><RoleSelector /></AuthShell>
}
