import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { Activity, ArrowUpRight, DollarSign, Package, TrendingUp, Users } from 'lucide-react'

const KPI_DATA = [
  { label: 'Total shipments', value: '12,480', change: '+12.8%', icon: Package, tone: 'blue' },
  { label: 'Delivered shipments', value: '10,940', change: '+9.4%', icon: Activity, tone: 'green' },
  { label: 'Active shipments', value: '842', change: '+5.7%', icon: TrendingUp, tone: 'cyan' },
  { label: 'Total revenue', value: '₹18.4L', change: '+22.1%', icon: DollarSign, tone: 'purple' },
]

const shipmentVolume = [
  { name: 'Jan', total: 180, onTime: 154 },
  { name: 'Feb', total: 210, onTime: 176 },
  { name: 'Mar', total: 246, onTime: 218 },
  { name: 'Apr', total: 260, onTime: 224 },
  { name: 'May', total: 290, onTime: 249 },
  { name: 'Jun', total: 312, onTime: 271 },
  { name: 'Jul', total: 335, onTime: 300 },
]

const statusData = [
  { name: 'Booked', value: 120 },
  { name: 'Assigned', value: 96 },
  { name: 'Picked Up', value: 84 },
  { name: 'In Transit', value: 196 },
  { name: 'Out for Delivery', value: 70 },
  { name: 'Delivered', value: 275 },
  { name: 'Cancelled', value: 18 },
]

const deliveryTypeData = [
  { name: 'Standard', value: 43 },
  { name: 'Express', value: 31 },
  { name: 'Same Day', value: 18 },
]

const revenueTrend = [
  { name: 'Mon', revenue: 72 },
  { name: 'Tue', revenue: 88 },
  { name: 'Wed', revenue: 92 },
  { name: 'Thu', revenue: 104 },
  { name: 'Fri', revenue: 120 },
  { name: 'Sat', revenue: 138 },
  { name: 'Sun', revenue: 125 },
]

const courierPerformance = [
  { name: 'Alex', deliveries: 98, success: 96 },
  { name: 'Priya', deliveries: 86, success: 93 },
  { name: 'Marcus', deliveries: 74, success: 91 },
  { name: 'Nina', deliveries: 68, success: 88 },
]

const customerData = [
  { name: 'Jan', customerGrowth: 8 },
  { name: 'Feb', customerGrowth: 10 },
  { name: 'Mar', customerGrowth: 13 },
  { name: 'Apr', customerGrowth: 15 },
  { name: 'May', customerGrowth: 18 },
  { name: 'Jun', customerGrowth: 22 },
]

const pieColors = ['#5de3ee', '#5c9dff', '#956bff']

function MetricCard({ item }) {
  const Icon = item.icon
  return (
    <article className="analytics-metric-card">
      <div className={`analytics-icon ${item.tone}`}>
        <Icon size={18} />
      </div>
      <div>
        <span>{item.label}</span>
        <strong>{item.value}</strong>
        <small>{item.change}</small>
      </div>
    </article>
  )
}

export default function AdminAnalytics() {
  return (
    <div className="page-shell analytics-shell">
      <div className="section-heading" style={{ marginBottom: 28 }}>
        <div className="eyebrow"><i /> BUSINESS INTELLIGENCE</div>
        <h2>Advanced courier analytics</h2>
      </div>

      <div className="analytics-grid metrics-grid">
        {KPI_DATA.map((item) => (
          <MetricCard key={item.label} item={item} />
        ))}
      </div>

      <div className="analytics-grid two-col">
        <div className="analytics-panel">
          <div className="analytics-panel-header">
            <h3>Shipment volume</h3>
            <span className="inline-badge">30 days</span>
          </div>
          <div style={{ width: '100%', height: 270 }}>
            <ResponsiveContainer>
              <BarChart data={shipmentVolume}>
                <CartesianGrid stroke="rgba(135,156,185,0.12)" vertical={false} />
                <XAxis dataKey="name" stroke="#7a8ca8" />
                <YAxis stroke="#7a8ca8" />
                <Tooltip />
                <Bar dataKey="total" fill="#5c9dff" radius={[8, 8, 0, 0]} />
                <Bar dataKey="onTime" fill="#5de3ee" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="analytics-panel">
          <div className="analytics-panel-header">
            <h3>Status distribution</h3>
            <span className="inline-badge">live</span>
          </div>
          <div style={{ width: '100%', height: 270 }}>
            <ResponsiveContainer>
              <PieChart>
                <Pie data={statusData} dataKey="value" innerRadius={55} outerRadius={85} paddingAngle={4}>
                  {statusData.map((entry, index) => (
                    <Cell key={entry.name} fill={pieColors[index % pieColors.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="analytics-grid two-col">
        <div className="analytics-panel">
          <div className="analytics-panel-header">
            <h3>Revenue by day</h3>
            <span className="inline-badge">₹</span>
          </div>
          <div style={{ width: '100%', height: 260 }}>
            <ResponsiveContainer>
              <AreaChart data={revenueTrend}>
                <defs>
                  <linearGradient id="chartFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#956bff" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#956bff" stopOpacity={0.1} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="rgba(135,156,185,0.12)" vertical={false} />
                <XAxis dataKey="name" stroke="#7a8ca8" />
                <YAxis stroke="#7a8ca8" />
                <Tooltip />
                <Area type="monotone" dataKey="revenue" stroke="#956bff" fill="url(#chartFill)" strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="analytics-panel">
          <div className="analytics-panel-header">
            <h3>Delivery type mix</h3>
            <span className="inline-badge">split</span>
          </div>
          <div style={{ width: '100%', height: 260 }}>
            <ResponsiveContainer>
              <BarChart data={deliveryTypeData}>
                <CartesianGrid stroke="rgba(135,156,185,0.12)" vertical={false} />
                <XAxis dataKey="name" stroke="#7a8ca8" />
                <YAxis stroke="#7a8ca8" />
                <Tooltip />
                <Bar dataKey="value" fill="#5c9dff" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="analytics-grid two-col">
        <div className="analytics-panel">
          <div className="analytics-panel-header">
            <h3>Courier performance</h3>
            <span className="inline-badge">ranking</span>
          </div>
          <div className="analytics-table-wrap">
            <table className="analytics-table">
              <thead>
                <tr>
                  <th>Courier</th>
                  <th>Deliveries</th>
                  <th>Success</th>
                </tr>
              </thead>
              <tbody>
                {courierPerformance.map((person) => (
                  <tr key={person.name}>
                    <td>{person.name}</td>
                    <td>{person.deliveries}</td>
                    <td>{person.success}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="analytics-panel">
          <div className="analytics-panel-header">
            <h3>Customer growth</h3>
            <span className="inline-badge">trend</span>
          </div>
          <div style={{ width: '100%', height: 260 }}>
            <ResponsiveContainer>
              <AreaChart data={customerData}>
                <CartesianGrid stroke="rgba(135,156,185,0.12)" vertical={false} />
                <XAxis dataKey="name" stroke="#7a8ca8" />
                <YAxis stroke="#7a8ca8" />
                <Tooltip />
                <Area type="monotone" dataKey="customerGrowth" stroke="#5de3ee" fill="#5de3ee" fillOpacity={0.2} strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="analytics-grid info-grid">
        <div className="info-banner">
          <span className="eyebrow"><i /> DELIVERY PERFORMANCE</span>
          <h3>On-time delivery</h3>
          <strong>87.4%</strong>
          <p>Based on actual shipment completion and delivery history.</p>
        </div>
        <div className="info-banner alt">
          <span className="eyebrow"><i /> CUSTOMER ANALYTICS</span>
          <h3>Returning customers</h3>
          <strong>64%</strong>
          <p>Retention remains stable across the last 90 days.</p>
        </div>
        <div className="info-banner alt-two">
          <span className="eyebrow"><i /> ALERTS</span>
          <h3>Operational watch</h3>
          <strong>7</strong>
          <p>Delivery delays and payment anomalies are under review.</p>
        </div>
      </div>
    </div>
  )
}
