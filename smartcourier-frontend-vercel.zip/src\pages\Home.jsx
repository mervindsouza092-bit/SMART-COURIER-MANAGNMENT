import { motion } from 'framer-motion'
import { Activity, Bell, BrainCircuit, Check, ChevronRight, Clock3, Gauge, LineChart, Navigation, Route, Sparkles, Truck, Users, Zap } from 'lucide-react'
import Button from '../components/Button'
import SectionHeading from '../components/SectionHeading'
import TrackingMap from '../components/TrackingMap'
import { fadeUp, scaleIn, slideLeft, staggerContainer } from '../animations/variants'

const features = [
  [Navigation, 'SMART TRACKING', 'Every shipment, visible. Every milestone, intelligently surfaced.'],
  [Zap, 'FAST DELIVERY', 'Optimized dispatch that turns distance into dependable arrival.'],
  [Route, 'AI ROUTE OPTIMIZATION', 'Dynamic routes that adapt to the city as it moves.'],
  [Users, 'COURIER MANAGEMENT', 'One clear command layer for your entire delivery network.'],
  [Bell, 'REAL-TIME NOTIFICATIONS', 'The right update, at the right moment, on every device.'],
  [LineChart, 'DELIVERY ANALYTICS', 'Turn daily movement into a clearer view of tomorrow.'],
]
const stats = [['10K+', 'DELIVERIES'], ['500+', 'COURIERS'], ['25+', 'CITIES'], ['99%', 'SUCCESS RATE']]
const intelligence = [[Route, 'SMART ROUTING', 'The shortest path is only the beginning.'], [Gauge, 'DELIVERY PREDICTION', 'Know what is next before it happens.'], [Users, 'COURIER ALLOCATION', 'Match every parcel to the right operator.'], [Activity, 'TRAFFIC ANALYSIS', 'Read the pulse of the city in real time.']]

function HeroVisual() {
  return <motion.div className="hero-visual" variants={slideLeft} initial="hidden" animate="visible"><div className="visual-label"><span><i /> NETWORK ACTIVE</span><b>NODE / 07</b></div><div className="city-map"><div className="roads r1" /><div className="roads r2" /><div className="roads r3" /><div className="roads r4" /><svg viewBox="0 0 520 430"><path className="visual-route" d="M60 340 C130 315 105 175 205 205 S305 390 450 100" /><circle cx="60" cy="340" r="6" /><circle cx="450" cy="100" r="6" /></svg><motion.div className="map-vehicle" animate={{ y: [0, -7, 0], rotate: [-2, 2, -2] }} transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}><Truck size={25} /></motion.div><div className="visual-pin start"><Navigation size={17} /></div><div className="visual-pin end"><div className="pin-pulse" /><Navigation size={17} /></div></div><motion.div className="data-card card-package" variants={scaleIn}><span>PACKAGE</span><strong>SC-20491</strong><small><i /> IN TRANSIT</small></motion.div><motion.div className="data-card card-eta" variants={scaleIn}><Clock3 size={16} /><span>ETA <b>24 MIN</b></span></motion.div><div className="coordinate">40° 42' 46.1" N<br />74° 00' 21.5" W</div></motion.div>
}

function AICore() {
  return <div className="ai-core"><div className="ai-orbit orbit-a" /><div className="ai-orbit orbit-b" /><div className="ai-orbit orbit-c" /><div className="ai-center"><BrainCircuit size={31} /><span>AI</span></div>{[1, 2, 3, 4].map((n) => <i key={n} className={`node node-${n}`} />)}<div className="ai-scan" /></div>
}

export default function Home() {
  return <div>
    <section className="hero page-shell"><div className="hero-copy"><motion.span className="eyebrow" initial={{ opacity: 0, x: -15 }} animate={{ opacity: 1, x: 0 }}><i /> LOGISTICS, REIMAGINED</motion.span><h1>{['THE', 'FUTURE OF', 'COURIER', 'MANAGEMENT.'].map((word, i) => <motion.span key={word} initial={{ opacity: 0, y: 35, scale: .95 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ delay: .15 + i * .1, duration: .7 }} className="headline-line">{word}</motion.span>)}</h1><motion.p className="hero-sub" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .65 }}>Intelligent logistics. Real-time tracking.<br /><span>Seamless deliveries.</span></motion.p><motion.div className="hero-actions" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .85 }}><Button to="/register">START SHIPPING</Button><Button to="/tracking" variant="button-ghost">TRACK PACKAGE</Button></motion.div><div className="hero-trust"><span><Check size={13} /> NO SETUP FEE</span><span><Check size={13} /> FULL VISIBILITY</span></div></div><HeroVisual /></section>
    <section className="network-section page-shell" id="services"><SectionHeading eyebrow="01 / LIVE OPERATIONS" title="See every move." align="center">One intelligent view of your entire delivery network, from pickup to doorstep.</SectionHeading><motion.div className="network-panel" variants={scaleIn} initial="hidden" whileInView="visible" viewport={{ once: true }}><TrackingMap /><div className="network-caption"><span>01 — ACTIVE ROUTE</span><b>NEW YORK <ChevronRight size={13} /> BOSTON</b><p>Route optimized 2 min ago</p></div></motion.div></section>
    <section className="features-section page-shell" id="features"><SectionHeading eyebrow="02 / THE PLATFORM" title="Built for the speed of now." /><motion.div className="feature-grid" variants={staggerContainer} initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }}>{features.map(([Icon, title, desc], i) => <motion.article className="feature-card" variants={fadeUp} key={title}><span className="feature-number">0{i + 1}</span><div className="icon-box"><Icon size={21} /></div><h3>{title}</h3><p>{desc}</p><span className="card-arrow">↗</span></motion.article>)}</motion.div></section>
    <section className="stats-section"><div className="page-shell stats-row">{stats.map(([number, label], i) => <motion.div className="stat" key={label} variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} transition={{ delay: i * .1 }}><strong>{number}</strong><span>{label}</span></motion.div>)}</div></section>
    <section className="how-section page-shell" id="how-it-works"><SectionHeading eyebrow="03 / SIMPLE BY DESIGN" title="From send to delivered." /><div className="timeline">{[['01', 'BOOK', 'Enter your shipment details.'], ['02', 'ASSIGN', 'A courier is assigned.'], ['03', 'TRACK', 'Monitor in real time.'], ['04', 'DELIVER', 'Receive it safely.']].map(([num, title, desc], i) => <motion.div className="timeline-step" variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} key={num}><div className="step-dot"><span>{num}</span></div><h3>{title}</h3><p>{desc}</p>{i < 3 && <div className="step-line" />}</motion.div>)}</div></section>
    <section className="ai-section page-shell"><div className="ai-copy"><SectionHeading eyebrow="04 / INTELLIGENCE LAYER" title="A smarter system for a moving world." >The network learns with every delivery. Our intelligence layer transforms complex logistics into simple, confident decisions.</SectionHeading><Button to="/register">EXPLORE THE PLATFORM</Button></div><AICore /><div className="ai-list">{intelligence.map(([Icon, title, desc]) => <div className="ai-item" key={title}><Icon size={18} /><span><b>{title}</b><small>{desc}</small></span></div>)}</div></section>
    <section className="cta-section page-shell"><div className="cta-inner"><Sparkles size={19} /><h2>READY TO MOVE YOUR<br /><span>DELIVERIES INTO THE FUTURE?</span></h2><p>Start building a more intelligent delivery operation today.</p><div><Button to="/register">START SHIPPING</Button><Button to="/tracking" variant="button-ghost">TRACK PACKAGE</Button></div></div></section>
  </div>
}
