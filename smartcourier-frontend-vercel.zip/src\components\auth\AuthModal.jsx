import { motion } from 'framer-motion'
import { CheckCircle2, XCircle } from 'lucide-react'

export default function AuthModal({ title, text, type = 'success', action }) {
  return <div className="modal-backdrop"><motion.div className="auth-modal" initial={{ opacity: 0, scale: .9 }} animate={{ opacity: 1, scale: 1 }}><div className={`modal-icon ${type}`}>{type === 'success' ? <CheckCircle2 /> : <XCircle />}</div><h3>{title}</h3><p>{text}</p>{action}</motion.div></div>
}
