import { CheckCircle2, Eye, EyeOff } from 'lucide-react'
import { useState } from 'react'

export default function Input({ label, type = 'text', value, onChange, error, required = true, placeholder = '', name }) {
  const [visible, setVisible] = useState(false)
  const isPassword = type === 'password'
  return <label className={`auth-field ${error ? 'has-error' : ''}`}><span>{label}{required && <em>*</em>}</span><div className="input-wrap"><input name={name} type={isPassword && !visible ? 'password' : 'text'} value={value} onChange={onChange} placeholder={placeholder} aria-invalid={Boolean(error)} />{value && !error && <CheckCircle2 className="valid-icon" size={15} />}{isPassword && <button type="button" className="password-toggle" onClick={() => setVisible(!visible)} aria-label={visible ? 'Hide password' : 'Show password'}>{visible ? <EyeOff size={16} /> : <Eye size={16} />}</button>}</div>{error && <small className="field-error">{error}</small>}</label>
}
