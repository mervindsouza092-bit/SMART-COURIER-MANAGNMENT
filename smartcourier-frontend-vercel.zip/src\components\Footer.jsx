import { Linkedin, Twitter, Github, ArrowUpRight } from 'lucide-react'
import { Link } from 'react-router-dom'

export default function Footer() {
  return <footer className="footer" id="about"><div className="footer-grid"><div className="footer-brand"><Link className="brand" to="/"><span className="brand-mark">✦</span><span>SMART <b>COURIER</b></span></Link><p>Moving deliveries into the future.</p></div><div><h4>PLATFORM</h4><Link to="/#features">Features</Link><Link to="/tracking">Tracking</Link><Link to="/#services">Services</Link><Link to="/#about">About</Link></div><div><h4>COMPANY</h4><a href="mailto:hello@smartcourier.io">Contact <ArrowUpRight size={13} /></a><a href="#privacy">Privacy</a><a href="#terms">Terms</a></div><div className="footer-connect"><h4>CONNECT</h4><p>Stay in the loop.</p><div className="socials"><a href="#linkedin" aria-label="LinkedIn"><Linkedin size={17} /></a><a href="#twitter" aria-label="Twitter"><Twitter size={17} /></a><a href="#github" aria-label="Github"><Github size={17} /></a></div></div></div><div className="footer-bottom"><span>© 2026 SMART COURIER SYSTEMS</span><span>DESIGNED FOR TOMORROW <i>●</i></span></div></footer>
}
