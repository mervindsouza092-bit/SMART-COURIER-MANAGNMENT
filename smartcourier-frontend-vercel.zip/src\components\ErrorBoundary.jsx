import React from 'react'

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props)
    this.state = { hasError: false }
  }

  static getDerivedStateFromError() {
    return { hasError: true }
  }

  componentDidCatch(error, errorInfo) {
    console.error('Application error boundary triggered', error, errorInfo)
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="page-shell" style={{ minHeight: '100vh', display: 'grid', placeItems: 'center' }}>
          <div className="error-boundary-card">
            <div className="error-boundary-icon">!</div>
            <h2>SYSTEM MODULE TEMPORARILY UNAVAILABLE</h2>
            <p>Something went wrong.</p>
            <button className="button" onClick={() => window.location.reload()}>Retry</button>
          </div>
        </div>
      )
    }

    return this.props.children
  }
}
