import { Activity, Clock3, LogOut, MapPinned, Navigation, PackageCheck, Radio, Route, Truck, UserRound } from 'lucide-react'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import AuthModal from '../components/auth/AuthModal'
import { useAuth } from '../context/AuthContext'
import { api } from '../services/api'

const statusFlow = ['Booked', 'Courier Assigned', 'Picked Up', 'In Transit', 'Out for Delivery', 'Delivered']

export default function Dashboard({ kind = 'user' }) {
  const [confirm, setConfirm] = useState(false)
  const [shipments, setShipments] = useState([])
  const [locationEnabled, setLocationEnabled] = useState(false)
  const { logout } = useAuth()
  const navigate = useNavigate()

  useEffect(() => {
    if (kind !== 'courier') return
    api('/courier/dashboard')
      .then((response) => setShipments(response.shipments || []))
      .catch(() => {
        setShipments([
          { _id: 'demo-1', trackingId: 'SC-2026-99401', status: 'Picked Up', destination: 'Pune', origin: 'Mumbai', amount: 1490 },
          { _id: 'demo-2', trackingId: 'SC-2026-99402', status: 'In Transit', destination: 'Nagpur', origin: 'Mumbai', amount: 2180 },
        ])
      })
  }, [kind])

  const handleStatusUpdate = async (shipmentId, nextStatus) => {
    try {
      const response = await api(`/courier/shipments/${shipmentId}/status`, {
        method: 'PATCH',
        body: { status: nextStatus, note: `Courier updated to ${nextStatus}` }
      })
      setShipments((current) => current.map((item) => item._id === response.shipment._id ? response.shipment : item))
    } catch {
      setShipments((current) => current.map((item) => item._id === shipmentId ? { ...item, status: nextStatus } : item))
    }
  }

  const handleLocationToggle = async () => {
    const next = !locationEnabled
    setLocationEnabled(next)
    try {
      await api(next ? '/courier/location/start' : '/courier/location/stop', { method: 'POST' })
    } catch (error) {
      console.error(error)
    }
  }

  const content = {
    user: ['USER COMMAND CENTER', 'Your personalized delivery dashboard is being initialized.', 'SYSTEM ONLINE', UserRound],
    admin: ['LOGISTICS COMMAND CENTER', 'Administrative control systems initialized.', 'ADMIN ACCESS GRANTED', Radio],
    courier: ['COURIER CONTROL CENTER', 'Your assigned delivery network is being initialized.', 'COURIER ACCESS GRANTED', Radio]
  }[kind]
  const Icon = content[3]

  if (kind !== 'courier') {
    return <section className="dashboard-placeholder page-shell"><div className="dashboard-card"><div className="dashboard-scan" /><Icon size={32} /><span className="eyebrow"><i />{content[2]}</span><h1>{content[0]}</h1><p>{content[1]}</p><div className="system-status"><i /> ALL SYSTEMS NOMINAL <span>/// 2035.09.17</span></div><button className="button logout-button" onClick={() => setConfirm(true)}><LogOut size={15} /> LOGOUT</button></div>{confirm && <AuthModal title="END CURRENT SESSION?" text="You will need to authenticate again to access your command center." type="error" action={<div className="modal-actions"><button className="button button-ghost" onClick={() => setConfirm(false)}>CANCEL</button><button className="button" onClick={() => { logout(); navigate('/login') }}>LOGOUT</button></div>} />}</section>
  }

  const active = shipments[0] || { trackingId: 'SC-2026-99401', status: 'In Transit', origin: 'Mumbai', destination: 'Pune' }

  return (
    <section className="page-shell shell-space courier-dashboard">
      <div className="section-heading"><span className="eyebrow"><i /> COURIER DASHBOARD</span><h2>Delivery command center</h2></div>

      <div className="stats-grid">
        <article className="kpi-card"><div className="kpi-icon purple"><Truck size={18} /></div><strong>{shipments.length || 2}</strong><span>Today's deliveries</span></article>
        <article className="kpi-card"><div className="kpi-icon cyan"><Navigation size={18} /></div><strong>{shipments.filter((item) => ['Picked Up', 'In Transit', 'Out for Delivery'].includes(item.status)).length || 1}</strong><span>Active delivery</span></article>
        <article className="kpi-card"><div className="kpi-icon green"><PackageCheck size={18} /></div><strong>{shipments.filter((item) => item.status === 'Delivered').length || 0}</strong><span>Completed</span></article>
        <article className="kpi-card"><div className="kpi-icon orange"><Activity size={18} /></div><strong>₹{shipments.reduce((sum, item) => sum + Number(item.amount || 0), 0).toLocaleString('en-IN')}</strong><span>Earnings</span></article>
      </div>

      <div className="tracking-grid lower-grid">
        <div className="card-block panel-glow">
          <div className="card-heading"><h3>Active delivery</h3><button className="button button-small button-ghost" onClick={handleLocationToggle}>{locationEnabled ? 'Stop location sharing' : 'Start location sharing'}</button></div>
          <div className="shipment-details-grid">
            <div><span>Tracking ID</span><strong>{active.trackingId}</strong></div>
            <div><span>Status</span><strong>{active.status}</strong></div>
            <div><span>Pickup</span><strong>{active.origin}</strong></div>
            <div><span>Destination</span><strong>{active.destination}</strong></div>
            <div><span>Delivery type</span><strong>Express</strong></div>
            <div><span>Live</span><strong>{locationEnabled ? '● LIVE' : '○ OFFLINE'}</strong></div>
          </div>

          <div className="live-summary-row">
            <button className="button button-small" onClick={() => handleStatusUpdate(active._id, 'Picked Up')}>Mark as Picked Up</button>
            <button className="button button-small button-ghost" onClick={() => handleStatusUpdate(active._id, 'In Transit')}>Start Transit</button>
            <button className="button button-small button-ghost" onClick={() => handleStatusUpdate(active._id, 'Out for Delivery')}>Out for Delivery</button>
            <button className="button button-small" onClick={() => handleStatusUpdate(active._id, 'Delivered')}>Mark as Delivered</button>
          </div>
        </div>

        <div className="card-block panel-glow">
          <div className="card-heading"><h3>Status control</h3></div>
          <div className="timeline-list">
            {statusFlow.map((step) => (
              <div key={step} className={`timeline-item ${active.status === step ? 'active' : ''}`}>
                <div className="timeline-dot" />
                <div>
                  <strong>{step}</strong>
                  <small>{active.status === step ? 'Current stage' : 'Available status'}</small>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="card-block panel-glow" style={{ marginTop: '1rem' }}>
        <div className="card-heading"><h3>Assigned shipments</h3></div>
        <div className="table-wrap">
          <table className="user-table">
            <thead><tr><th>Tracking ID</th><th>Route</th><th>Package</th><th>Status</th><th>ETA</th></tr></thead>
            <tbody>
              {shipments.map((shipment) => (
                <tr key={shipment._id || shipment.trackingId}>
                  <td>{shipment.trackingId}</td>
                  <td>{shipment.origin} → {shipment.destination}</td>
                  <td>{shipment.service || 'Express'}</td>
                  <td><span className="status-badge status-in-transit">{shipment.status}</span></td>
                  <td><div className="status-block"><Clock3 size={13} /> 25 min</div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {confirm && <AuthModal title="END CURRENT SESSION?" text="You will need to authenticate again to access your command center." type="error" action={<div className="modal-actions"><button className="button button-ghost" onClick={() => setConfirm(false)}>CANCEL</button><button className="button" onClick={() => { logout(); navigate('/login') }}>LOGOUT</button></div>} />}
    </section>
  )
}
