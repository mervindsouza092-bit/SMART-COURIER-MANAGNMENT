import { motion } from 'framer-motion'
import { fadeUp } from '../animations/variants'

export default function SectionHeading({ eyebrow, title, children, align = '' }) {
  return <motion.div className={`section-heading ${align}`} variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }}>
    <span className="eyebrow"><i />{eyebrow}</span><h2>{title}</h2>{children && <p>{children}</p>}
  </motion.div>
}
