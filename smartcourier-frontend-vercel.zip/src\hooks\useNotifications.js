import { useEffect, useState } from 'react'

export function useNotifications() {
  const [notifications, setNotifications] = useState([])

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem('smartCourierNotifications') || '[]')
    setNotifications(stored)
  }, [])

  const addNotification = (notification) => {
    const next = [notification, ...notifications]
    setNotifications(next)
    localStorage.setItem('smartCourierNotifications', JSON.stringify(next))
  }

  return { notifications, addNotification }
}
