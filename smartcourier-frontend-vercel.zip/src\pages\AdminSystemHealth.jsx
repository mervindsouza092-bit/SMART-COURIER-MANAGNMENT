const components = [
  { name: 'API STATUS', state: 'ONLINE', detail: 'Response latency: 118ms' },
  { name: 'DATABASE', state: 'CONNECTED', detail: 'MongoDB replication stable' },
  { name: 'SOCKET SERVER', state: 'ONLINE', detail: '128 active sockets' },
  { name: 'PAYMENT SERVICE', state: 'ONLINE', detail: 'Gateway status green' },
  { name: 'MAP SERVICE', state: 'ONLINE', detail: 'Tiles served normally' },
  { name: 'AI SERVICES', state: 'ONLINE', detail: 'Model queue stable' },
]

export default function AdminSystemHealth() {
  return (
    <div className="page-shell analytics-shell">
      <div className="section-heading" style={{ marginBottom: 22 }}>
        <div className="eyebrow"><i /> SYSTEM HEALTH</div>
        <h2>Operational infrastructure</h2>
      </div>

      <div className="health-grid">
        {components.map((item) => (
          <article key={item.name} className="alert-card health-card">
            <div className="alert-header">
              <span className="inline-badge">{item.name}</span>
              <span className="priority-pill green">{item.state}</span>
            </div>
            <p>{item.detail}</p>
          </article>
        ))}
      </div>
    </div>
  )
}
