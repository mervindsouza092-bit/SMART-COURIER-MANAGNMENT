export default function Loading({ label = 'PROCESSING...' }) {
  return <span className="loading-label"><i />{label}</span>
}
