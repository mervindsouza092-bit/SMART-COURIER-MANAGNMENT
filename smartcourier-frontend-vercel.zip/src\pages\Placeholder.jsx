import { motion } from 'framer-motion'
import { ArrowLeft, LockKeyhole } from 'lucide-react'
import { Link } from 'react-router-dom'
import TrackingMap from '../components/TrackingMap'

export default function Placeholder({ title, eyebrow, tracking = false }) {
  return <section className="placeholder page-shell"><div className="placeholder-inner"><motion.span className="eyebrow" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}><LockKeyhole size={13} /> {eyebrow}</motion.span><motion.h1 initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0, transition: { delay: .1 } }}>{title}</motion.h1><p>Coming in <b>Phase 2</b>. This experience is being prepared for the next mission.</p>{tracking && <div className="placeholder-map"><TrackingMap /></div>}<Link className="back-link" to="/"><ArrowLeft size={15} /> Return to home</Link></div></section>
}
