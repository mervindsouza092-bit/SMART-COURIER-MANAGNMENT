import { AnimatePresence, motion } from 'framer-motion'
import { CheckCircle2, XCircle } from 'lucide-react'

export default function Toast({ toast, onClose }) {
  return <AnimatePresence>{toast && <motion.div className={`toast ${toast.type}`} initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 30 }} onClick={onClose}>{toast.type === 'error' ? <XCircle size={17} /> : <CheckCircle2 size={17} />}<span>{toast.message}</span></motion.div>}</AnimatePresence>
}
